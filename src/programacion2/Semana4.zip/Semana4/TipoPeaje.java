/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package programacion2.Semana4;

/**
 *
 * @author User
 */
public enum TipoPeaje {
    LIVIANO,EJES2,EJES3,EJES4
}
